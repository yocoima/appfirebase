import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bitacora-tareas',
  templateUrl: './bitacora-tareas.component.html'
})
export class BitacoraTareasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
