import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-tarea',
  templateUrl: './new-tarea.component.html'
})
export class NewTareaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
