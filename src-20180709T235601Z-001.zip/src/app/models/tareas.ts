export class Tareas {
  $key:string;
  clasificacion:string;
  tarea:string;
  importancia:string;
  periodo: string;
}
