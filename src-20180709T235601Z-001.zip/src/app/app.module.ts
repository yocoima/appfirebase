import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';

// para BD Firebase
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule, AngularFireDatabase } from 'angularfire2/database';
import { environment } from '../environments/environment';
// SERVICIOS
import { ConexionbdService } from './servicios/conexionbd.service';

// COMPONENTES
import { AppComponent } from './app.component';
import { InicioSesionComponent } from './components/inicio-sesion/inicio-sesion.component';
import { NewTareaComponent } from './components/new-tarea/new-tarea.component';
import { BitacoraTareasComponent } from './components/bitacora-tareas/bitacora-tareas.component';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { Tareas } from './models/tareas';

// RUTAS
import { APP_ROUTING } from './app.routes';


@NgModule({
  declarations: [
    AppComponent,
    InicioSesionComponent,
    NavbarComponent,
    NewTareaComponent,
    BitacoraTareasComponent
  ],
  imports: [
    BrowserModule,
    APP_ROUTING,
    AngularFireModule.initializeApp(environment.firebase),
    FormsModule
  ],
  providers: [ConexionbdService,Tareas, AngularFireDatabase],
  bootstrap: [AppComponent]
})
export class AppModule { }
